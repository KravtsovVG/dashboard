angular.
        module('Constants', [])
